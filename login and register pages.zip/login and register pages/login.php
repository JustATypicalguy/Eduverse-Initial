<?php

session_start();

include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $email = $_POST['email'];

  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");

  $stmt->bindParam(':email', $email);
  
  $stmt->execute();
  
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if ($user) {
  
    if (password_verify($password, $user['password'])) {
  
      $_SESSION['user_id'] = $user['id'];
  
      $_SESSION['role'] = $user['role'];

      if ($user['role'] == 'admin') {
      
        header("Location: admin.php");
      
        exit();
      
      } else {
      
        header("Location: dashboard.php");
      
        exit();
      
      }
    
    } else {
    
      echo "<script>alert('❌ كلمة المرور غير صحيحة');</script>";
    
    }
  
  } else {
  
    echo "<script>alert('❌ البريد الإلكتروني غير مسجل');</script>";
  
  }

}

?>

<!DOCTYPE html> 

<html lang="ar"> 

<head> 

<meta charset="UTF-8"> 

<title>login</title> 

<style> 

body{
  font-family:Cairo;
  background:#f2f2f2;
  direction:rtl;
} 

.container{
  width:400px;
  margin:60px auto;
  background:white;
  padding:20px;
  border-radius:10px;
  direction:rtl;
} 

input{
  width:100%;
  padding:10px;
  margin:5px 0;
  border:1px solid #ccc;
  border-radius:5px;
  direction:rtl;
} 

button{
  width:100%;
  background:#28a745;
  color:white;
  padding:10px;
  border:none;
  border-radius:5px;
} 

a{
  text-decoration:none;
  color:#007bff;
} 

</style> 

</head> 

<body> 

<div class="container"> 

<h2>login</h2> 

<form method="POST"> 

  <input type="email" name="email" placeholder="email" required><br>

  <input type="password" name="password" placeholder="password" required><br>

  <button type="submit">login</button> <br>

</form> 

<p>Dont have an account?<a href="register.php">cerate new accounnt</a></p>

</div> 

</body>

</html>