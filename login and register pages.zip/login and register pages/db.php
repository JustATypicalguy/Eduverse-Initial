<?php
$conn = pg_connect("host=ep-royal-queen-adcwm620-pooler.c-2.us-east-1.aws.neon.tech
                    port=5432
                    dbname=neondb
                    user=neondb_owner
                    password=npg_VvyLhEw2g7NR
                    sslmode=require
                    options=--endpoint=ep-royal-queen-adcwm620");

if (!$conn) {
    die("❌ فشل الاتصال بقاعدة البيانات");
} else {
    echo "✅ تم الاتصال بنجاح";
}
?>