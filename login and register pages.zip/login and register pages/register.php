<?php 

include("db.php"); 

 

if ($_SERVER["REQUEST_METHOD"] == "POST") { 

  $name = $_POST['name']; 

  $email = $_POST['email']; 

  $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 

  $grade = $_POST['grade'];

  $groops = $_POST['group_id'];

  $aproved = $_POST['aproved'];

  $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?"); 

  $stmt->bind_param("sss", $name, $email, $password); 


  if ($stmt->execute()) { 

      header('location: login.php');

  } else { 

    echo "<script>alert('البريد الإلكتروني مستخدم من قبل ⚠️');</script>"; 

  } 


} 

?> 

<!DOCTYPE html> 

<html lang="ar"> 

<head> 

<meta charset="UTF-8"> 

<title>تسجيل حساب جديد</title> 

<style> 

body 
{
  font-family:Cairo;
  background:#f2f2f2; 
  direction:rtl;
} 

.container
{
  width:400px; 
  margin:60px auto; 
  background:white; 
  padding:20px; 
  border-radius:10px;
} 

.input
{
  width:100%; 
  padding:10px; 
  margin:5px 0; 
  border:1px solid #ccc; 
  border-radius:5px;
} 

input
{
  width:100%; 
  padding:10px; 
  margin:5px 0; 
  border:1px solid #ccc; 
  border-radius:5px;
} 

button
{
  width:100%; 
  background:#007bff; 
  color:white; 
  padding:10px; 
  border:none; 
  border-radius:5px;
} 

a
{
  text-decoration:none; 
  color:#007bff;
} 

</style> 

</head> 

<body> 

 

<div class="container"> 

<h2>📝 إنشاء حساب جديد</h2> 

<form method="POST"> 

  <input type="text" name="name" placeholder="الاسم الكامل" required> 

  <input type="email" name="email" placeholder="البريد الإلكتروني" required> 

  <input type="password" name="password" placeholder="كلمة المرور" required><br>
  
  <button type="submit">تسجيل</button> 

</form> 

<p>هل لديك حساب؟ <a href="login.php">تسجيل الدخول</a></p> 

</div> 

</body> 

</html> 